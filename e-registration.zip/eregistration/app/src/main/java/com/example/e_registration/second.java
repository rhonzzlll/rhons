package com.example.e_registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class second extends AppCompatActivity {
    EditText ed1,ed2,ed3;
    Button prevButton,contButton ,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ed1 = findViewById(R.id.Age);
        ed2 = findViewById(R.id.Fname);
        ed3 = findViewById(R.id.vacName);

        prevButton = findViewById(R.id.prevButton);
        contButton = findViewById(R.id.contiButton);


        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int1 = new Intent(second.this,options.class);
                startActivity(int1);

            }
        });
        contButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int2 = new Intent(second.this,next.class);
                startActivity(int2);

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String age = ed1.getText().toString();
                String fullname = ed2.getText().toString();
                String mbnum  = ed3.getText().toString();

                if (age.isEmpty() || fullname.isEmpty() || mbnum.isEmpty()) {
                    Toast.makeText(second.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(second.this, next.class);
                    intent.putExtra("keyed1", age);
                    intent.putExtra("keyed2", fullname);
                    intent.putExtra("keyed3", mbnum);
                    startActivity(intent);
                    return;
                }
            }
        });

    }
}
