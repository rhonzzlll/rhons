package com.example.e_registration;

import static android.text.TextUtils.isEmpty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class next extends AppCompatActivity {
    EditText ed1, ed2, ed3;
    Button btn1,btn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);


        ed1 = findViewById(R.id.vacDate);
        ed2 = findViewById(R.id.mobNum);
        ed3 = findViewById(R.id.email);

        btn1 = findViewById(R.id.prevButton);
        btn2 = findViewById(R.id.submitButton);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int1 = new Intent(next.this,first.class);
                startActivity(int1);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String vaccdate= ed1.getText().toString();
                String mobNum = ed2.getText().toString();
                String emails = ed3.getText().toString();



                if(isEmpty(vaccdate)) {
                    ed1.setError("Please enter a vaccination date");
            return;
                }

                if(isEmpty(mobNum)) {
                    ed2.setError("Please enter a mobile number");
                    return;
                }

                if(isEmpty(emails)) {
                    ed3.setError("Please enter an email");
                    return;

                }

                Intent intent = new Intent(next.this,verify.class);

                intent.putExtra("keyed4",vaccdate);
                intent.putExtra("keyed5",mobNum);
                intent.putExtra("keyed6",emails);
                startActivity(intent);
                return;
            }
        });


    }
}