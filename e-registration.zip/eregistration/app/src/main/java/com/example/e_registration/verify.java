package com.example.e_registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class verify extends AppCompatActivity {

    Button btn1;



    TextView txt1,txt2,txt3,txt4,txt5,txt6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);


        Intent intent = getIntent();


        String fullname = intent.getStringExtra("keyed1");
        String age = intent.getStringExtra("keyed2");
        String vaccname = intent.getStringExtra("keyed3");
        String vaccdate = intent.getStringExtra("keyed4");
        String mobNum = intent.getStringExtra("keyed5");
        String emails = intent.getStringExtra("keyed6");


        txt1 = findViewById(R.id.ffName);
        txt2 = findViewById(R.id.ages);
        txt3 = findViewById(R.id.textviewVaccineName);
        txt4 = findViewById(R.id.textViewVaccineDate);
        txt5 = findViewById(R.id.mbNum);
        txt6 = findViewById(R.id.textViewEmail);
        btn1 = findViewById(R.id.confirmBtn);


        txt1.setText(fullname);
        txt2.setText(age);
        txt3.setText(vaccname);
        txt4.setText(vaccdate);
        txt5.setText(mobNum);
        txt6.setText(emails);
        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent int1 = new Intent(verify.this,confirm.class);
                startActivity(int1);
            }
        });

    }
}