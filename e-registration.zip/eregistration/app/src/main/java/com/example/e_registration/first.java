package com.example.e_registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;

public class first extends AppCompatActivity {
    TextView txt1,txt2,txt3,txt4,txt5,txt6;
    EditText ed1,ed2;
    EditText ed3;
Button btn1,btn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        ed1 = findViewById(R.id.Fname);
        ed2 = findViewById(R.id.Age);
        ed3 = findViewById(R.id.vacName);

        btn1 = findViewById(R.id.prevButton);
      btn2 = findViewById(R.id.contiButton);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int1 = new Intent(first.this,options.class);
                startActivity(int1);

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fullname= ed1.getText().toString();
                String age= ed2.getText().toString();
                String vaccname = ed3.getText().toString();

                txt1 =findViewById(R.id.ffName);
                txt2 =findViewById(R.id.ages);
                txt3 =findViewById(R.id.textviewVaccineName);

                if (age.isEmpty() || fullname.isEmpty() || vaccname.isEmpty()) {
                    Toast.makeText(first.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(first.this,next.class);
                    intent.putExtra("keyed1", fullname);
                    intent.putExtra("keyed2", age);
                    intent.putExtra("keyed3", vaccname);

                    startActivity(intent);
                    return;

                }
            }
        });

    }
}